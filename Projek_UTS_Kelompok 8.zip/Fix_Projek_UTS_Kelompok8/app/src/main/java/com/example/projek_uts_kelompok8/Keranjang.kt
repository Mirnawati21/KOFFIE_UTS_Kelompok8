package com.example.projek_uts_kelompok8;

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import com.example.projek_uts_kelompok8.R

class Keranjang : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_keranjang)
        supportActionBar?.hide()

        val backmenu = findViewById<Button>(R.id.backmenu)

        backmenu.setOnClickListener {
            // intent digunakan untuk memanggil / menampilkan activity baru
            val inten = Intent(this@Keranjang, Daftar_Menu::class.java)
            startActivity(inten)

            val bar = supportActionBar
            bar!!.title = "Keranjang"
            bar.setDisplayHomeAsUpEnabled(true)
        }
    }
        override fun onSupportNavigateUp(): Boolean {
            onBackPressed()
            return true
        }
    }

