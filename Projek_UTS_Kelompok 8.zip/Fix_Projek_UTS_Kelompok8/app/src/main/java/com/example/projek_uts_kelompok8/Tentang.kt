package com.example.projek_uts_kelompok8

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class Tentang : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_tentang)
        supportActionBar?.hide()

        val back = findViewById<Button>(R.id.back)

        back.setOnClickListener {
            // intent digunakan untuk memanggil / menampilkan activity baru
            val inten = Intent( this@Tentang,MainActivity::class.java)
            startActivity(inten)
        }
    }
}