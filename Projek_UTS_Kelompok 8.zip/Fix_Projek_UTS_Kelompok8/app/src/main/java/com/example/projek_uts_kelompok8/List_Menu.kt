package com.example.projek_uts_kelompok8;

import android.media.Rating
import android.widget.RatingBar

class List_Menu(val nama_menu: String ="", val harga_menu: String="", val foto_menu: Int=0, val rating: Double){

}