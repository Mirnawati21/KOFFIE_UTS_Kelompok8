package com.example.projek_uts_kelompok8

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import java.text.NumberFormat
import java.util.Locale

class VanilaLatte : AppCompatActivity() {
    private var numericValue: Int = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_vanila_latte)

        val bar = supportActionBar
        bar!!.title = "Vanila Latte"
        bar.setDisplayHomeAsUpEnabled(true)

        val button_keranjang = findViewById<Button>(R.id.button_keranjang)
        val total_harga = findViewById<TextView>(R.id.total_harga)
        val jumlah = findViewById<EditText>(R.id.kuantitas)

        total_harga.text = "0"
        // Set a TextWatcher to listen for text changes
        jumlah.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
                // Update numericValue whenever the text changes
                numericValue = s.toString().toIntOrNull() ?: 0
                total_harga.text = "0"
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                // Not used in this example
                total_harga.text = "0"
            }

            override fun afterTextChanged(s: Editable?) {
                // Update numericValue whenever the text changes
                numericValue = s.toString().toIntOrNull() ?: 0

                val kalkulasi_total = numericValue * 35000
                val formatter = NumberFormat.getCurrencyInstance(Locale.getDefault())
                total_harga.text = formatter.format(kalkulasi_total)

            }
        })

        button_keranjang.setOnClickListener {
            val inten = Intent( this,Keranjang::class.java)
            startActivity(inten)
            Toast.makeText(this, "Pesanan Anda akan di proses", Toast.LENGTH_LONG).show()
        }
    }
    // FUntion to back
    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return true
    }
}